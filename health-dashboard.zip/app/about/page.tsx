import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Scissors, Star, Users } from "lucide-react"

export default function AboutPage() {
  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section className="relative h-[50vh] w-full overflow-hidden bg-black">
        <div className="absolute inset-0 bg-gradient-to-r from-black/80 to-black/40 z-10"></div>
        <div className="absolute inset-0 bg-[url('/images/about-hero.jpg')] bg-cover bg-center opacity-50"></div>
        <div className="container relative z-20 flex h-full flex-col items-center justify-center text-center">
          <h1 className="font-playfair text-4xl md:text-6xl font-bold text-white mb-4">About Royal Breed Fashions</h1>
          <p className="max-w-2xl text-lg md:text-xl text-gray-200">Crafting excellence in men's fashion since 2015</p>
        </div>
      </section>

      {/* Our Story */}
      <section className="py-20">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl md:text-4xl font-playfair font-bold mb-6">Our Story</h2>
              <p className="text-gray-600 dark:text-gray-300 mb-4">
                Royal Breed Fashions was founded with a singular vision: to create exceptional men's fashion that
                combines traditional craftsmanship with contemporary design. Our journey began in 2015 when our founder,
                Prosper Somtochukwu Emeaso, recognized a gap in the market for high-quality, custom-tailored menswear
                that truly reflected the personality and status of the wearer.
              </p>
              <p className="text-gray-600 dark:text-gray-300 mb-4">
                What started as a small tailoring shop has grown into a respected fashion brand, serving clients across
                Nigeria and beyond. Our commitment to quality, attention to detail, and personalized service has earned
                us a reputation as one of the premier men's fashion designers in the region.
              </p>
              <p className="text-gray-600 dark:text-gray-300">
                Today, Royal Breed Fashions continues to push the boundaries of men's fashion, blending traditional
                techniques with innovative designs to create garments that are both timeless and contemporary.
              </p>
            </div>
            <div className="relative h-[500px] rounded-lg overflow-hidden shadow-xl">
              <Image
                src="/placeholder.svg?height=500&width=400"
                alt="Royal Breed Fashions workshop"
                fill
                className="object-cover"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Our Values */}
      <section className="py-20 bg-gray-50 dark:bg-gray-900">
        <div className="container">
          <h2 className="text-3xl md:text-4xl font-playfair font-bold text-center mb-16">Our Values</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Card className="bg-white dark:bg-gray-800 border-none shadow-lg">
              <CardContent className="p-8 text-center">
                <div className="h-16 w-16 rounded-full bg-gold/10 flex items-center justify-center mx-auto mb-6">
                  <Star className="h-8 w-8 text-gold" />
                </div>
                <h3 className="text-xl font-bold mb-4">Excellence</h3>
                <p className="text-gray-600 dark:text-gray-300">
                  We are committed to excellence in every aspect of our work, from the selection of fabrics to the final
                  stitch. We believe that true quality is in the details.
                </p>
              </CardContent>
            </Card>
            <Card className="bg-white dark:bg-gray-800 border-none shadow-lg">
              <CardContent className="p-8 text-center">
                <div className="h-16 w-16 rounded-full bg-gold/10 flex items-center justify-center mx-auto mb-6">
                  <Scissors className="h-8 w-8 text-gold" />
                </div>
                <h3 className="text-xl font-bold mb-4">Craftsmanship</h3>
                <p className="text-gray-600 dark:text-gray-300">
                  We honor the tradition of tailoring through meticulous craftsmanship. Each garment is created with
                  precision and care, ensuring a perfect fit and finish.
                </p>
              </CardContent>
            </Card>
            <Card className="bg-white dark:bg-gray-800 border-none shadow-lg">
              <CardContent className="p-8 text-center">
                <div className="h-16 w-16 rounded-full bg-gold/10 flex items-center justify-center mx-auto mb-6">
                  <Users className="h-8 w-8 text-gold" />
                </div>
                <h3 className="text-xl font-bold mb-4">Customer Focus</h3>
                <p className="text-gray-600 dark:text-gray-300">
                  Our clients are at the heart of everything we do. We listen, understand, and deliver garments that
                  exceed expectations and reflect individual style.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Our Team */}
      <section className="py-20">
        <div className="container">
          <h2 className="text-3xl md:text-4xl font-playfair font-bold text-center mb-16">Meet Our Team</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="relative h-80 w-full rounded-lg overflow-hidden mb-4">
                <Image
                  src="/placeholder.svg?height=320&width=240"
                  alt="Prosper Somtochukwu Emeaso"
                  fill
                  className="object-cover"
                />
              </div>
              <h3 className="text-xl font-bold mb-1">Prosper Somtochukwu Emeaso</h3>
              <p className="text-gold mb-2">Founder & Lead Designer</p>
              <p className="text-gray-600 dark:text-gray-300 text-sm">
                With over 10 years of experience in fashion design, Prosper brings creativity and vision to every
                collection.
              </p>
            </div>
            <div className="text-center">
              <div className="relative h-80 w-full rounded-lg overflow-hidden mb-4">
                <Image src="/placeholder.svg?height=320&width=240" alt="Team Member" fill className="object-cover" />
              </div>
              <h3 className="text-xl font-bold mb-1">Emmanuel Okafor</h3>
              <p className="text-gold mb-2">Master Tailor</p>
              <p className="text-gray-600 dark:text-gray-300 text-sm">
                Emmanuel's precision and attention to detail ensure that every garment meets our high standards.
              </p>
            </div>
            <div className="text-center">
              <div className="relative h-80 w-full rounded-lg overflow-hidden mb-4">
                <Image src="/placeholder.svg?height=320&width=240" alt="Team Member" fill className="object-cover" />
              </div>
              <h3 className="text-xl font-bold mb-1">Chioma Nwosu</h3>
              <p className="text-gold mb-2">Client Relations Manager</p>
              <p className="text-gray-600 dark:text-gray-300 text-sm">
                Chioma ensures that every client receives personalized attention and exceptional service.
              </p>
            </div>
            <div className="text-center">
              <div className="relative h-80 w-full rounded-lg overflow-hidden mb-4">
                <Image src="/placeholder.svg?height=320&width=240" alt="Team Member" fill className="object-cover" />
              </div>
              <h3 className="text-xl font-bold mb-1">David Adeyemi</h3>
              <p className="text-gold mb-2">Fabric Specialist</p>
              <p className="text-gray-600 dark:text-gray-300 text-sm">
                David's expertise in textiles helps clients select the perfect fabric for their needs and preferences.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 bg-black text-white">
        <div className="container text-center">
          <h2 className="text-3xl md:text-4xl font-playfair font-bold mb-6">Experience the Royal Breed Difference</h2>
          <p className="max-w-2xl mx-auto text-lg text-gray-300 mb-8">
            Ready to elevate your style? Contact us today to schedule a consultation or browse our collection of
            designs.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button asChild size="lg" className="bg-gold hover:bg-gold/90 text-black">
              <Link href="/contact">Contact Us</Link>
            </Button>
            <Button asChild size="lg" variant="outline" className="border-gold text-gold hover:bg-gold/10">
              <Link href="/designs">Explore Designs</Link>
            </Button>
          </div>
        </div>
      </section>
    </div>
  )
}
