"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Search } from "lucide-react"

// Sample FAQ data - in a real app, this would come from your database
const faqCategories = {
  general: [
    {
      question: "What is Royal Breed Fashions?",
      answer:
        "Royal Breed Fashions is a premium men's fashion design brand specializing in custom-tailored suits, shirts, and traditional attire. We provide bespoke clothing services with a focus on quality craftsmanship and personalized customer experience.",
    },
    {
      question: "Where are you located?",
      answer:
        "Our main showroom is located in Lagos, Nigeria. However, we serve clients nationwide and internationally through our online services.",
    },
    {
      question: "Do you ship internationally?",
      answer:
        "Yes, we offer international shipping. Delivery times and costs vary depending on the destination. Please contact us for specific shipping information to your location.",
    },
    {
      question: "How can I contact customer support?",
      answer:
        "You can reach our customer support team by phone at +2348069305651, by email at info@royalbreedfashions.com, or through the contact form on our website.",
    },
  ],
  orders: [
    {
      question: "How do I place an order?",
      answer:
        "To place an order, you need to create an account, submit your measurements, select a design (or upload your own), and proceed to payment. Our step-by-step process guides you through each stage.",
    },
    {
      question: "What is the typical turnaround time for orders?",
      answer:
        "Our standard turnaround time is 2-3 weeks for custom tailoring, depending on our current workload and the complexity of the design. Rush orders may be accommodated for an additional fee.",
    },
    {
      question: "Can I modify my order after it's been placed?",
      answer:
        "Minor modifications can be made within 24 hours of placing your order. For significant changes after this period, please contact our customer service team as soon as possible.",
    },
    {
      question: "What is your return policy?",
      answer:
        "Since our products are custom-made, we do not accept returns unless there is a defect in craftsmanship or materials. However, we offer alterations if your garment doesn't fit perfectly.",
    },
  ],
  measurements: [
    {
      question: "How do I submit my measurements?",
      answer:
        "You can submit your measurements through your account dashboard after registering. We provide detailed instructions and diagrams to help you take accurate measurements. Alternatively, you can upload clear pictures of yourself for our tailors to assess.",
    },
    {
      question: "What if I don't know how to take my measurements?",
      answer:
        "We provide comprehensive guides with illustrations on how to take your measurements correctly. If you're still unsure, you can schedule a video consultation with one of our tailors who will guide you through the process.",
    },
    {
      question: "What if my garment doesn't fit properly?",
      answer:
        "If your garment doesn't fit as expected, please contact us within 7 days of receiving it. We offer alterations to ensure a perfect fit. In some cases, we may require you to send photos or videos to assess the fit issues.",
    },
  ],
  payment: [
    {
      question: "What payment methods do you accept?",
      answer:
        "We accept payments via PayPal, Opay, Palmpay, Nigerian bank transfers, and international bank transfers. All payments are processed securely.",
    },
    {
      question: "Is a deposit required?",
      answer:
        "Yes, we require a 50% deposit to begin work on your order. The remaining balance is due before shipping or delivery.",
    },
    {
      question: "Are there any additional fees?",
      answer:
        "Shipping fees are calculated based on your location. For international orders, import duties and taxes may apply, which are the responsibility of the customer.",
    },
    {
      question: "Is my payment information secure?",
      answer:
        "Yes, we use industry-standard encryption and secure payment processors to protect your financial information. We do not store your payment details on our servers.",
    },
  ],
}

export default function FAQPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [activeTab, setActiveTab] = useState("general")
  const [filteredFAQs, setFilteredFAQs] = useState<{ [key: string]: { question: string; answer: string }[] }>({
    ...faqCategories,
  })

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()

    if (!searchQuery.trim()) {
      setFilteredFAQs({ ...faqCategories })
      return
    }

    const query = searchQuery.toLowerCase()
    const filtered: { [key: string]: { question: string; answer: string }[] } = {}

    Object.entries(faqCategories).forEach(([category, questions]) => {
      const matchingQuestions = questions.filter(
        (q) => q.question.toLowerCase().includes(query) || q.answer.toLowerCase().includes(query),
      )

      if (matchingQuestions.length > 0) {
        filtered[category] = matchingQuestions
      }
    })

    setFilteredFAQs(filtered)
  }

  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section className="relative h-[40vh] w-full overflow-hidden bg-black">
        <div className="absolute inset-0 bg-gradient-to-r from-black/80 to-black/40 z-10"></div>
        <div className="absolute inset-0 bg-[url('/images/faq-hero.jpg')] bg-cover bg-center opacity-50"></div>
        <div className="container relative z-20 flex h-full flex-col items-center justify-center text-center">
          <h1 className="font-playfair text-4xl md:text-6xl font-bold text-white mb-4">Frequently Asked Questions</h1>
          <p className="max-w-2xl text-lg md:text-xl text-gray-200">
            Find answers to common questions about our services
          </p>
        </div>
      </section>

      {/* Search and FAQ Content */}
      <section className="py-20">
        <div className="container">
          {/* Search Bar */}
          <div className="max-w-2xl mx-auto mb-12">
            <form onSubmit={handleSearch} className="relative">
              <Input
                type="text"
                placeholder="Search for answers..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pr-12"
              />
              <Button type="submit" size="icon" className="absolute right-1 top-1 bg-gold hover:bg-gold/90 text-black">
                <Search className="h-4 w-4" />
              </Button>
            </form>
          </div>

          {/* FAQ Tabs and Content */}
          <div className="max-w-4xl mx-auto">
            <Tabs defaultValue="general" value={activeTab} onValueChange={setActiveTab}>
              <TabsList className="grid w-full grid-cols-2 md:grid-cols-4 mb-8">
                <TabsTrigger value="general">General</TabsTrigger>
                <TabsTrigger value="orders">Orders</TabsTrigger>
                <TabsTrigger value="measurements">Measurements</TabsTrigger>
                <TabsTrigger value="payment">Payment</TabsTrigger>
              </TabsList>

              {Object.keys(filteredFAQs).length === 0 ? (
                <div className="text-center py-12">
                  <h3 className="text-xl font-bold mb-2">No results found</h3>
                  <p className="text-gray-600 dark:text-gray-300 mb-6">
                    We couldn't find any FAQs matching your search query.
                  </p>
                  <Button
                    onClick={() => {
                      setSearchQuery("")
                      setFilteredFAQs({ ...faqCategories })
                    }}
                    variant="outline"
                  >
                    Clear Search
                  </Button>
                </div>
              ) : (
                Object.entries(faqCategories).map(([category, _]) => (
                  <TabsContent key={category} value={category} className="mt-0">
                    {filteredFAQs[category] ? (
                      <Accordion type="single" collapsible className="w-full">
                        {filteredFAQs[category].map((faq, index) => (
                          <AccordionItem key={index} value={`item-${index}`}>
                            <AccordionTrigger className="text-left font-medium">{faq.question}</AccordionTrigger>
                            <AccordionContent className="text-gray-600 dark:text-gray-300">
                              {faq.answer}
                            </AccordionContent>
                          </AccordionItem>
                        ))}
                      </Accordion>
                    ) : (
                      <div className="text-center py-8">
                        <p className="text-gray-600 dark:text-gray-300">No results found in this category.</p>
                      </div>
                    )}
                  </TabsContent>
                ))
              )}
            </Tabs>
          </div>
        </div>
      </section>

      {/* Ask a Question */}
      <section className="py-16 bg-gray-50 dark:bg-gray-900">
        <div className="container">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-3xl font-playfair font-bold mb-4">Didn't Find Your Answer?</h2>
            <p className="text-gray-600 dark:text-gray-300 mb-8">
              Contact us directly and we'll be happy to help with any questions you may have.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button asChild size="lg" className="bg-gold hover:bg-gold/90 text-black">
                <Link href="/contact">Contact Us</Link>
              </Button>
              <Button asChild size="lg" variant="outline">
                <Link href="/account/login">Login to Your Account</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
