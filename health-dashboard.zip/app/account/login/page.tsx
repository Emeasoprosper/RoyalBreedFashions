"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Checkbox } from "@/components/ui/checkbox"
import { useToast } from "@/components/ui/use-toast"
import { useRouter } from "next/navigation"
import { Eye, EyeOff, Loader2 } from "lucide-react"
import { useAuth } from "@/lib/auth-context"

export default function LoginPage() {
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [rememberMe, setRememberMe] = useState(false)
  const [showPassword, setShowPassword] = useState(false)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [error, setError] = useState("")

  const router = useRouter()
  const { toast } = useToast()
  const { login } = useAuth()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!email || !password) {
      setError("Please enter both email and password")
      return
    }

    setIsSubmitting(true)
    setError("")

    // Simulate API call for login
    setTimeout(() => {
      setIsSubmitting(false)

      // For demo purposes, accept any login
      login({ email })

      toast({
        title: "Login Successful!",
        description: "Welcome back to Royal Breed Fassions.",
      })

      // Redirect to dashboard
      router.push("/account/dashboard")
    }, 1500)
  }

  return (
    <div className="flex min-h-screen">
      {/* Left Side - Image */}
      <div className="hidden lg:block relative w-0 flex-1">
        <div className="absolute inset-0 bg-black">
          <div className="absolute inset-0 bg-gradient-to-r from-black/80 to-black/40 z-10"></div>
          <div className="absolute inset-0 bg-[url('/images/login-bg.jpg')] bg-cover bg-center opacity-70"></div>
          <div className="absolute inset-0 flex items-center justify-center z-20">
            <div className="max-w-md text-center text-white p-6">
              <h2 className="text-3xl font-playfair font-bold mb-4">Welcome Back</h2>
              <p className="text-lg mb-6">
                Sign in to access your account, track orders, and manage your custom designs.
              </p>
              <div className="bg-white/10 backdrop-blur-sm rounded-lg p-6">
                <blockquote className="italic mb-4">
                  "Royal Breed Fashions has completely transformed my wardrobe. The attention to detail and quality of
                  craftsmanship is unmatched."
                </blockquote>
                <div className="flex items-center justify-center">
                  <div className="relative h-10 w-10 rounded-full overflow-hidden mr-3">
                    <Image src="/placeholder.svg?height=40&width=40" alt="Customer" fill className="object-cover" />
                  </div>
                  <div className="text-left">
                    <p className="font-medium">John Doe</p>
                    <p className="text-sm text-gray-300">Loyal Customer</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Right Side - Form */}
      <div className="flex-1 flex flex-col justify-center py-12 px-4 sm:px-6 lg:px-8">
        <div className="mx-auto w-full max-w-sm">
          <div className="text-center mb-8">
            <Link href="/">
              <Image
                src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Copy%20of%20ROYALBREED.jpg-7YL9WfU5iw7CtZzGQyQ0vuhXLxzcKh.jpeg"
                alt="Royal Breed Fassions"
                width={180}
                height={70}
                className="h-16 w-16 rounded-full object-cover mx-auto"
              />
            </Link>
            <h2 className="mt-6 text-3xl font-playfair font-bold">Sign in to your account</h2>
            <p className="mt-2 text-sm text-gray-600 dark:text-gray-400">
              Enter your credentials to access your account
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            {error && <div className="p-3 bg-red-100 border border-red-400 text-red-700 rounded">{error}</div>}

            <div className="space-y-2">
              <Label htmlFor="email">Email Address</Label>
              <Input id="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label htmlFor="password">Password</Label>
                <Link href="/account/forgot-password" className="text-sm text-gold hover:underline">
                  Forgot password?
                </Link>
              </div>
              <div className="relative">
                <Input
                  id="password"
                  type={showPassword ? "text" : "password"}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  className="pr-10"
                />
                <button
                  type="button"
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500"
                  onClick={() => setShowPassword(!showPassword)}
                >
                  {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
            </div>

            <div className="flex items-center space-x-2">
              <Checkbox
                id="rememberMe"
                checked={rememberMe}
                onCheckedChange={(checked) => setRememberMe(checked === true)}
              />
              <label htmlFor="rememberMe" className="text-sm text-gray-600 dark:text-gray-400">
                Remember me
              </label>
            </div>

            <Button type="submit" className="w-full bg-gold hover:bg-gold/90 text-black" disabled={isSubmitting}>
              {isSubmitting ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Signing in...
                </>
              ) : (
                "Sign in"
              )}
            </Button>
          </form>

          <div className="mt-6 text-center">
            <p className="text-sm text-gray-600 dark:text-gray-400">
              Don't have an account?{" "}
              <Link href="/account/register" className="text-gold hover:underline font-medium">
                Create an account
              </Link>
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}
