import { Button } from "@/components/ui/button"
import Image from "next/image"
import Link from "next/link"
import { ArrowRight, Scissors, Shirt, ShoppingBag, Star, Users } from "lucide-react"
import FeaturedDesigns from "@/components/home/featured-designs"
import TestimonialSlider from "@/components/home/testimonial-slider"
import NewsletterSignup from "@/components/home/newsletter-signup"

export default function Home() {
  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section className="relative h-[90vh] w-full overflow-hidden bg-black">
        <div className="absolute inset-0 bg-gradient-to-r from-black/80 to-black/40 z-10"></div>
        <div className="absolute inset-0 bg-[url('/images/hero-bg.jpg')] bg-cover bg-center opacity-50"></div>
        <div className="container relative z-20 flex h-full flex-col items-center justify-center text-center">
          <Image
            src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Copy%20of%20ROYALBREED.jpg-7YL9WfU5iw7CtZzGQyQ0vuhXLxzcKh.jpeg"
            alt="Royal Breed Fassions Logo"
            width={400}
            height={200}
            className="mb-8 h-32 w-32 rounded-full object-cover"
          />
          <h1 className="font-playfair text-4xl md:text-6xl font-bold text-gold mb-4">Royal Breed Fassions</h1>
          <p className="max-w-2xl text-lg md:text-xl text-gray-200 mb-8">Elevate your stiles.....elevate your breed</p>
          <div className="flex flex-col sm:flex-row gap-4">
            <Button asChild size="lg" className="bg-gold hover:bg-gold/90 text-black">
              <Link href="/designs">Explore Designs</Link>
            </Button>
            <Button asChild size="lg" variant="outline" className="border-gold text-gold hover:bg-gold/10">
              <Link href="/account/register">Create Account</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-gray-50 dark:bg-gray-900">
        <div className="container">
          <h2 className="text-3xl md:text-4xl font-playfair font-bold text-center mb-16">The Royal Breed Experience</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="flex flex-col items-center text-center p-6 bg-white dark:bg-gray-800 rounded-lg shadow-md">
              <div className="h-16 w-16 rounded-full bg-gold/10 flex items-center justify-center mb-4">
                <Scissors className="h-8 w-8 text-gold" />
              </div>
              <h3 className="text-xl font-bold mb-2">Custom Tailoring</h3>
              <p className="text-gray-600 dark:text-gray-300">
                Precision measurements and expert craftsmanship for the perfect fit.
              </p>
            </div>
            <div className="flex flex-col items-center text-center p-6 bg-white dark:bg-gray-800 rounded-lg shadow-md">
              <div className="h-16 w-16 rounded-full bg-gold/10 flex items-center justify-center mb-4">
                <Shirt className="h-8 w-8 text-gold" />
              </div>
              <h3 className="text-xl font-bold mb-2">Premium Fabrics</h3>
              <p className="text-gray-600 dark:text-gray-300">
                Sourced from the finest mills around the world for exceptional quality.
              </p>
            </div>
            <div className="flex flex-col items-center text-center p-6 bg-white dark:bg-gray-800 rounded-lg shadow-md">
              <div className="h-16 w-16 rounded-full bg-gold/10 flex items-center justify-center mb-4">
                <Star className="h-8 w-8 text-gold" />
              </div>
              <h3 className="text-xl font-bold mb-2">Unique Designs</h3>
              <p className="text-gray-600 dark:text-gray-300">
                Distinctive styles that set you apart and make a statement.
              </p>
            </div>
            <div className="flex flex-col items-center text-center p-6 bg-white dark:bg-gray-800 rounded-lg shadow-md">
              <div className="h-16 w-16 rounded-full bg-gold/10 flex items-center justify-center mb-4">
                <Users className="h-8 w-8 text-gold" />
              </div>
              <h3 className="text-xl font-bold mb-2">Personal Service</h3>
              <p className="text-gray-600 dark:text-gray-300">
                Dedicated attention to ensure your complete satisfaction.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Designs */}
      <FeaturedDesigns />

      {/* How It Works */}
      <section className="py-20 bg-gray-50 dark:bg-gray-900">
        <div className="container">
          <h2 className="text-3xl md:text-4xl font-playfair font-bold text-center mb-16">How It Works</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="relative flex flex-col items-center text-center p-6">
              <div className="absolute -top-4 -left-4 h-12 w-12 rounded-full bg-gold text-black flex items-center justify-center font-bold text-xl">
                1
              </div>
              <h3 className="text-xl font-bold mb-4 mt-8">Create Your Account</h3>
              <p className="text-gray-600 dark:text-gray-300 mb-4">
                Sign up and verify your account to get started with Royal Breed Fashions.
              </p>
              <Button asChild variant="link" className="text-gold">
                <Link href="/account/register">
                  Register Now <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>
            </div>
            <div className="relative flex flex-col items-center text-center p-6">
              <div className="absolute -top-4 -left-4 h-12 w-12 rounded-full bg-gold text-black flex items-center justify-center font-bold text-xl">
                2
              </div>
              <h3 className="text-xl font-bold mb-4 mt-8">Submit Measurements</h3>
              <p className="text-gray-600 dark:text-gray-300 mb-4">
                Provide your measurements manually or upload a clear picture for precise tailoring.
              </p>
              <Button asChild variant="link" className="text-gold">
                <Link href="/measurements">
                  Learn More <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>
            </div>
            <div className="relative flex flex-col items-center text-center p-6">
              <div className="absolute -top-4 -left-4 h-12 w-12 rounded-full bg-gold text-black flex items-center justify-center font-bold text-xl">
                3
              </div>
              <h3 className="text-xl font-bold mb-4 mt-8">Select Your Design</h3>
              <p className="text-gray-600 dark:text-gray-300 mb-4">
                Choose from our catalog or upload your own design inspiration for customization.
              </p>
              <Button asChild variant="link" className="text-gold">
                <Link href="/designs">
                  Browse Designs <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <TestimonialSlider />

      {/* CTA Section */}
      <section className="py-20 bg-black text-white">
        <div className="container text-center">
          <h2 className="text-3xl md:text-4xl font-playfair font-bold mb-6">Ready to Elevate Your Style?</h2>
          <p className="max-w-2xl mx-auto text-lg text-gray-300 mb-8">
            Join Royal Breed Fashions today and experience the difference that premium, custom-tailored fashion can
            make.
          </p>
          <Button asChild size="lg" className="bg-gold hover:bg-gold/90 text-black">
            <Link href="/designs">
              <ShoppingBag className="mr-2 h-5 w-5" /> Shop Now
            </Link>
          </Button>
        </div>
      </section>

      {/* Newsletter */}
      <NewsletterSignup />
    </div>
  )
}
