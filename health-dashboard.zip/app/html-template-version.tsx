"use client"

import { useState, useEffect } from "react"
import { PieChart, Pie, Cell, ResponsiveContainer, Sector } from "recharts"
import { motion } from "framer-motion"

export default function HTMLTemplateVersion() {
  const [activeIndex, setActiveIndex] = useState<number | null>(null)
  const [isLoaded, setIsLoaded] = useState(false)

  useEffect(() => {
    setIsLoaded(true)
  }, [])

  const data = [
    { name: "Population", value: 90.3, color: "gray" },
    { name: "Cured", value: 8.0, color: "green" },
    { name: "Death", value: 1.7, color: "red" },
  ]

  const renderActiveShape = (props: any) => {
    const { cx, cy, innerRadius, outerRadius, startAngle, endAngle, fill, payload, percent, value } = props

    return (
      <g>
        <Sector
          cx={cx}
          cy={cy}
          innerRadius={innerRadius}
          outerRadius={outerRadius + 10}
          startAngle={startAngle}
          endAngle={endAngle}
          fill={fill}
        />
        <text x={cx} y={cy} dy={-20} textAnchor="middle" fill="#333" fontSize={16} fontWeight="bold">
          {payload.name}
        </text>
        <text x={cx} y={cy} textAnchor="middle" fill="#333" fontSize={20} fontWeight="bold">
          {`${value}%`}
        </text>
      </g>
    )
  }

  const onPieEnter = (_: any, index: number) => {
    setActiveIndex(index)
  }

  const onPieLeave = () => {
    setActiveIndex(null)
  }

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
      },
    },
  }

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        duration: 0.5,
      },
    },
  }

  return (
    <div style={{ fontFamily: "Arial, sans-serif", margin: 0, padding: "20px", backgroundColor: "#f5f5f5" }}>
      <motion.div
        initial="hidden"
        animate={isLoaded ? "visible" : "hidden"}
        variants={containerVariants}
        className="container"
        style={{ display: "flex", gap: "20px", alignItems: "stretch" }}
      >
        {/* Right side - Chart */}
        <motion.div variants={itemVariants} className="right distribution" style={{ flex: 1 }}>
          <div
            className="distribution"
            style={{ backgroundColor: "#ebfefe", padding: "5%", borderRadius: "10px", height: "100%" }}
          >
            <h1>Population Distribution</h1>
            <p>This pie chart shows the distribution of the total population into cured, death, and others.</p>
            <div style={{ height: "400px", width: "100%" }}>
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    activeIndex={activeIndex !== null ? activeIndex : undefined}
                    activeShape={renderActiveShape}
                    data={data}
                    cx="50%"
                    cy="50%"
                    innerRadius={70}
                    outerRadius={110}
                    dataKey="value"
                    onMouseEnter={onPieEnter}
                    onMouseLeave={onPieLeave}
                  >
                    {data.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} stroke="#fff" strokeWidth={2} />
                    ))}
                  </Pie>
                </PieChart>
              </ResponsiveContainer>
            </div>
          </div>
        </motion.div>

        {/* Left side - Legend, Summary, Suggestions */}
        <motion.div
          variants={itemVariants}
          className="left distribution"
          style={{ flex: 1, display: "flex", flexDirection: "column" }}
        >
          {/* Legend */}
          <motion.div
            className="legend"
            style={{
              backgroundColor: "#ebfefe",
              padding: "5%",
              borderRadius: "10px",
              marginBottom: "20px",
              flex: 1,
            }}
            whileHover={{ boxShadow: "0 10px 25px rgba(0, 0, 0, 0.1)" }}
          >
            <h1>LEGENDS</h1>
            <motion.div whileHover={{ x: 5 }}>
              <div
                className="ash"
                style={{
                  width: "30px",
                  height: "30px",
                  marginBottom: "10px",
                  borderRadius: "5px",
                  backgroundColor: "gray",
                }}
              ></div>
              <p>Population percentage</p>
            </motion.div>

            <motion.div whileHover={{ x: 5 }}>
              <div
                className="green"
                style={{
                  width: "30px",
                  height: "30px",
                  marginBottom: "10px",
                  borderRadius: "5px",
                  backgroundColor: "green",
                }}
              ></div>
              <p>Cured percentage</p>
            </motion.div>

            <motion.div whileHover={{ x: 5 }}>
              <div
                className="red"
                style={{
                  width: "30px",
                  height: "30px",
                  marginBottom: "10px",
                  borderRadius: "5px",
                  backgroundColor: "red",
                }}
              ></div>
              <p>Death percentage</p>
            </motion.div>
          </motion.div>

          {/* Summary */}
          <motion.div
            className="summary"
            style={{
              backgroundColor: "#ebfefe",
              padding: "5%",
              borderRadius: "10px",
              marginBottom: "20px",
              flex: 1,
            }}
            whileHover={{ boxShadow: "0 10px 25px rgba(0, 0, 0, 0.1)" }}
          >
            <h1>SUMMARY</h1>
            <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.5 }}>
              This chart displays the health statistics for India. The data shows that 90.3% of the population is
              healthy, 8.0% have been cured from illnesses, and 1.7% have unfortunately passed away.
            </motion.p>
          </motion.div>

          {/* Suggestions */}
          <motion.div
            className="suggestions"
            style={{
              backgroundColor: "#ebfefe",
              padding: "5%",
              borderRadius: "10px",
              flex: 1,
            }}
            whileHover={{ boxShadow: "0 10px 25px rgba(0, 0, 0, 0.1)" }}
          >
            <h1>SUGGESTIONS</h1>
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.9 }}>
              <p>Based on the current data, we recommend:</p>
              <ul style={{ paddingLeft: "20px" }}>
                <motion.li initial={{ x: -20, opacity: 0 }} animate={{ x: 0, opacity: 1 }} transition={{ delay: 1.0 }}>
                  Maintain current healthcare initiatives that have successfully kept mortality rates low
                </motion.li>
              </ul>
            </motion.div>
          </motion.div>
        </motion.div>
      </motion.div>
    </div>
  )
}
