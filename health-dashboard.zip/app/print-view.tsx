"use client"

import { useRef } from "react"
import { Button } from "@/components/ui/button"
import { Printer } from "lucide-react"

export default function PrintView() {
  const printRef = useRef<HTMLDivElement>(null)

  const data = [
    { name: "Population", value: 90.3, color: "gray" },
    { name: "Cured", value: 8.0, color: "green" },
    { name: "Death", value: 1.7, color: "red" },
  ]

  const handlePrint = () => {
    const content = printRef.current
    if (!content) return

    const printWindow = window.open("", "_blank")
    if (!printWindow) return

    // Create print content
    printWindow.document.write(`
      <html>
        <head>
          <title>Population Distribution Report</title>
          <style>
            body {
              font-family: Arial, sans-serif;
              padding: 20px;
            }
            .print-container {
              max-width: 800px;
              margin: 0 auto;
            }
            .header {
              text-align: center;
              margin-bottom: 20px;
              padding-bottom: 10px;
              border-bottom: 1px solid #ccc;
            }
            .content {
              display: flex;
              flex-wrap: wrap;
            }
            .chart-container {
              width: 50%;
              padding: 10px;
            }
            .info-container {
              width: 50%;
              padding: 10px;
            }
            .box {
              border: 1px solid #ccc;
              padding: 15px;
              margin-bottom: 15px;
              background-color: #f9f9f9;
            }
            .legend-item {
              display: flex;
              align-items: center;
              margin-bottom: 10px;
            }
            .color-box {
              width: 20px;
              height: 20px;
              margin-right: 10px;
            }
            .footer {
              margin-top: 30px;
              text-align: center;
              font-size: 12px;
              color: #666;
            }
            @media print {
              button {
                display: none;
              }
            }
          </style>
        </head>
        <body>
          <div class="print-container">
            <div class="header">
              <h1>Population Distribution Report</h1>
              <p>Generated on ${new Date().toLocaleDateString()}</p>
            </div>
            
            <div class="content">
              <div class="chart-container">
                <div class="box">
                  <h2>Population Distribution</h2>
                  <p>This chart shows the distribution of the total population into cured, death, and others.</p>
                  <div style="text-align: center; margin-top: 20px;">
                    <div style="font-size: 18px; font-weight: bold; margin-bottom: 10px;">Population: 90.3%</div>
                    <div style="font-size: 18px; font-weight: bold; margin-bottom: 10px;">Cured: 8.0%</div>
                    <div style="font-size: 18px; font-weight: bold;">Death: 1.7%</div>
                  </div>
                </div>
              </div>
              
              <div class="info-container">
                <div class="box">
                  <h2>LEGENDS</h2>
                  <div class="legend-item">
                    <div class="color-box" style="background-color: gray;"></div>
                    <p>Population percentage</p>
                  </div>
                  <div class="legend-item">
                    <div class="color-box" style="background-color: green;"></div>
                    <p>Cured percentage</p>
                  </div>
                  <div class="legend-item">
                    <div class="color-box" style="background-color: red;"></div>
                    <p>Death percentage</p>
                  </div>
                </div>
                
                <div class="box">
                  <h2>SUMMARY</h2>
                  <p>This chart displays the health statistics for all of India in 2025. The data shows that 90.3% of the population is healthy, 8.0% have been cured from illnesses, and 1.7% have unfortunately passed away.</p>
                </div>
                
                <div class="box">
                  <h2>SUGGESTIONS</h2>
                  <p>Based on the current data, we recommend:</p>
                  <ul>
                    <li>Maintain current healthcare initiatives that have successfully kept mortality rates low</li>
                    <li>Share successful treatment protocols with other regions to maintain high cure rates</li>
                    <li>Implement preventive healthcare measures to maintain the healthy population percentage</li>
                  </ul>
                </div>
              </div>
            </div>
            
            <div class="footer">
              <p>Data last updated: May 2025 | Source: Ministry of Health</p>
            </div>
          </div>
        </body>
      </html>
    `)

    printWindow.document.close()

    // Wait for content to load then print
    setTimeout(() => {
      printWindow.print()
    }, 500)
  }

  return (
    <div className="p-6 bg-[#ebfefe] rounded-lg shadow-lg">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold">Print Preview</h2>
        <Button onClick={handlePrint} className="flex items-center gap-2">
          <Printer className="h-4 w-4" />
          Print Report
        </Button>
      </div>

      <div ref={printRef} className="border rounded-lg p-6 bg-white">
        <div className="text-center mb-6 pb-4 border-b">
          <h1 className="text-2xl font-bold">Population Distribution Report</h1>
          <p className="text-gray-500">Generated on {new Date().toLocaleDateString()}</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <div className="border rounded-lg p-4 mb-4">
              <h2 className="text-xl font-bold mb-2">Population Distribution</h2>
              <p className="text-gray-600 mb-4">
                This chart shows the distribution of the total population into cured, death, and others.
              </p>
              <div className="text-center space-y-2 mt-6">
                {data.map((item) => (
                  <div key={item.name} className="flex justify-between items-center py-2">
                    <span className="font-medium">{item.name}:</span>
                    <span className="font-bold">{item.value}%</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="space-y-4">
            <div className="border rounded-lg p-4">
              <h2 className="text-xl font-bold mb-2">LEGENDS</h2>
              {data.map((item) => (
                <div key={item.name} className="flex items-center gap-2 mb-2">
                  <div className="w-4 h-4" style={{ backgroundColor: item.color }}></div>
                  <span>{item.name} percentage</span>
                </div>
              ))}
            </div>

            <div className="border rounded-lg p-4">
              <h2 className="text-xl font-bold mb-2">SUMMARY</h2>
              <p className="text-gray-600">
                This chart displays the health statistics for all of India in 2025. The data shows that 90.3% of the
                population is healthy, 8.0% have been cured from illnesses, and 1.7% have unfortunately passed away.
              </p>
            </div>

            <div className="border rounded-lg p-4">
              <h2 className="text-xl font-bold mb-2">SUGGESTIONS</h2>
              <p className="text-gray-600 mb-2">Based on the current data, we recommend:</p>
              <ul className="list-disc pl-5 text-gray-600">
                <li>Maintain current healthcare initiatives that have successfully kept mortality rates low</li>
                <li>Share successful treatment protocols with other regions to maintain high cure rates</li>
                <li>Implement preventive healthcare measures to maintain the healthy population percentage</li>
              </ul>
            </div>
          </div>
        </div>

        <div className="text-center text-gray-500 text-sm mt-8 pt-4 border-t">
          Data last updated: May 2025 | Source: Ministry of Health
        </div>
      </div>
    </div>
  )
}
