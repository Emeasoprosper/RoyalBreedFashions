"use client"

import { useState, useEffect } from "react"
import { PieChart, Pie, Cell, ResponsiveContainer, Sector } from "recharts"
import { motion } from "framer-motion"
import { Filters } from "@/components/filters"
import { ThemeToggle } from "@/components/theme-toggle"

// Data for different regions and years
const dataByRegionAndYear = {
  all: {
    "2023": [
      { name: "Population", value: 89.5, color: "#6366f1" },
      { name: "Cured", value: 7.8, color: "#10b981" },
      { name: "Death", value: 2.7, color: "#ef4444" },
    ],
    "2024": [
      { name: "Population", value: 90.0, color: "#6366f1" },
      { name: "Cured", value: 7.9, color: "#10b981" },
      { name: "Death", value: 2.1, color: "#ef4444" },
    ],
    "2025": [
      { name: "Population", value: 90.3, color: "#6366f1" },
      { name: "Cured", value: 8.0, color: "#10b981" },
      { name: "Death", value: 1.7, color: "#ef4444" },
    ],
  },
  north: {
    "2023": [
      { name: "Population", value: 88.5, color: "#6366f1" },
      { name: "Cured", value: 8.5, color: "#10b981" },
      { name: "Death", value: 3.0, color: "#ef4444" },
    ],
    "2024": [
      { name: "Population", value: 89.2, color: "#6366f1" },
      { name: "Cured", value: 8.8, color: "#10b981" },
      { name: "Death", value: 2.0, color: "#ef4444" },
    ],
    "2025": [
      { name: "Population", value: 89.8, color: "#6366f1" },
      { name: "Cured", value: 9.0, color: "#10b981" },
      { name: "Death", value: 1.2, color: "#ef4444" },
    ],
  },
  south: {
    "2023": [
      { name: "Population", value: 91.0, color: "#6366f1" },
      { name: "Cured", value: 7.0, color: "#10b981" },
      { name: "Death", value: 2.0, color: "#ef4444" },
    ],
    "2024": [
      { name: "Population", value: 91.5, color: "#6366f1" },
      { name: "Cured", value: 7.2, color: "#10b981" },
      { name: "Death", value: 1.3, color: "#ef4444" },
    ],
    "2025": [
      { name: "Population", value: 92.0, color: "#6366f1" },
      { name: "Cured", value: 7.3, color: "#10b981" },
      { name: "Death", value: 0.7, color: "#ef4444" },
    ],
  },
  east: {
    "2023": [
      { name: "Population", value: 87.0, color: "#6366f1" },
      { name: "Cured", value: 9.0, color: "#10b981" },
      { name: "Death", value: 4.0, color: "#ef4444" },
    ],
    "2024": [
      { name: "Population", value: 87.8, color: "#6366f1" },
      { name: "Cured", value: 9.2, color: "#10b981" },
      { name: "Death", value: 3.0, color: "#ef4444" },
    ],
    "2025": [
      { name: "Population", value: 88.5, color: "#6366f1" },
      { name: "Cured", value: 9.5, color: "#10b981" },
      { name: "Death", value: 2.0, color: "#ef4444" },
    ],
  },
  west: {
    "2023": [
      { name: "Population", value: 90.5, color: "#6366f1" },
      { name: "Cured", value: 7.5, color: "#10b981" },
      { name: "Death", value: 2.0, color: "#ef4444" },
    ],
    "2024": [
      { name: "Population", value: 91.0, color: "#6366f1" },
      { name: "Cured", value: 7.8, color: "#10b981" },
      { name: "Death", value: 1.2, color: "#ef4444" },
    ],
    "2025": [
      { name: "Population", value: 91.5, color: "#6366f1" },
      { name: "Cured", value: 8.0, color: "#10b981" },
      { name: "Death", value: 0.5, color: "#ef4444" },
    ],
  },
  central: {
    "2023": [
      { name: "Population", value: 86.0, color: "#6366f1" },
      { name: "Cured", value: 10.0, color: "#10b981" },
      { name: "Death", value: 4.0, color: "#ef4444" },
    ],
    "2024": [
      { name: "Population", value: 87.0, color: "#6366f1" },
      { name: "Cured", value: 10.5, color: "#10b981" },
      { name: "Death", value: 2.5, color: "#ef4444" },
    ],
    "2025": [
      { name: "Population", value: 88.0, color: "#6366f1" },
      { name: "Cured", value: 11.0, color: "#10b981" },
      { name: "Death", value: 1.0, color: "#ef4444" },
    ],
  },
}

export default function HealthDashboardWithFilters() {
  const [activeIndex, setActiveIndex] = useState<number | null>(null)
  const [isLoaded, setIsLoaded] = useState(false)
  const [currentRegion, setCurrentRegion] = useState("all")
  const [currentYear, setCurrentYear] = useState("2025")
  const [data, setData] = useState(dataByRegionAndYear.all["2025"])

  useEffect(() => {
    setIsLoaded(true)
  }, [])

  const handleFilterChange = (region: string, year: string) => {
    setCurrentRegion(region)
    setCurrentYear(year)
    setData(
      dataByRegionAndYear[region as keyof typeof dataByRegionAndYear][year as keyof typeof dataByRegionAndYear.all],
    )
  }

  const renderActiveShape = (props: any) => {
    const { cx, cy, innerRadius, outerRadius, startAngle, endAngle, fill, payload, percent, value } = props

    return (
      <g>
        <Sector
          cx={cx}
          cy={cy}
          innerRadius={innerRadius}
          outerRadius={outerRadius + 10}
          startAngle={startAngle}
          endAngle={endAngle}
          fill={fill}
        />
        <text x={cx} y={cy} dy={-20} textAnchor="middle" fill="#333" fontSize={16} fontWeight="bold">
          {payload.name}
        </text>
        <text x={cx} y={cy} textAnchor="middle" fill="#333" fontSize={20} fontWeight="bold">
          {`${value}%`}
        </text>
      </g>
    )
  }

  const onPieEnter = (_: any, index: number) => {
    setActiveIndex(index)
  }

  const onPieLeave = () => {
    setActiveIndex(null)
  }

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
      },
    },
  }

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        duration: 0.5,
      },
    },
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-6 flex items-center justify-center">
      <motion.div
        initial="hidden"
        animate={isLoaded ? "visible" : "hidden"}
        variants={containerVariants}
        className="w-full max-w-5xl bg-white rounded-2xl shadow-2xl overflow-hidden"
      >
        <motion.div
          variants={itemVariants}
          className="bg-gradient-to-r from-blue-600 to-indigo-700 p-6 text-white flex justify-between items-center"
        >
          <h1 className="text-3xl font-bold">Population Distribution</h1>
          <ThemeToggle />
        </motion.div>

        <div className="p-6">
          <Filters onFilterChange={handleFilterChange} />

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 p-2">
            {/* Pie Chart */}
            <motion.div variants={itemVariants} className="flex items-center justify-center h-[400px]">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    activeIndex={activeIndex !== null ? activeIndex : undefined}
                    activeShape={renderActiveShape}
                    data={data}
                    cx="50%"
                    cy="50%"
                    innerRadius={80}
                    outerRadius={120}
                    dataKey="value"
                    onMouseEnter={onPieEnter}
                    onMouseLeave={onPieLeave}
                  >
                    {data.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} stroke="#fff" strokeWidth={2} />
                    ))}
                  </Pie>
                </PieChart>
              </ResponsiveContainer>
            </motion.div>

            {/* Right side boxes */}
            <div className="space-y-6">
              {/* Legend */}
              <motion.div
                variants={itemVariants}
                className="bg-white rounded-xl p-5 shadow-lg border border-gray-100 hover:shadow-xl transition-shadow duration-300"
                whileHover={{ scale: 1.02 }}
              >
                <h2 className="text-xl font-bold text-gray-800 border-b-2 border-indigo-100 pb-2 mb-4">LEGEND</h2>
                <div className="space-y-4">
                  {data.map((item, index) => (
                    <motion.div
                      key={index}
                      className="flex items-center gap-3"
                      whileHover={{ scale: 1.05 }}
                      transition={{ type: "spring", stiffness: 400, damping: 10 }}
                    >
                      <div className="w-5 h-5 rounded-sm" style={{ backgroundColor: item.color }}></div>
                      <span className="text-gray-700 font-medium">{item.name}</span>
                    </motion.div>
                  ))}
                </div>
              </motion.div>

              {/* Summary */}
              <motion.div
                variants={itemVariants}
                className="bg-white rounded-xl p-5 shadow-lg border border-gray-100 hover:shadow-xl transition-shadow duration-300"
                whileHover={{ scale: 1.02 }}
              >
                <h2 className="text-xl font-bold text-gray-800 border-b-2 border-indigo-100 pb-2 mb-4">SUMMARY</h2>
                <p className="text-gray-600 leading-relaxed">
                  This chart contains the percentage distribution of the population health status in
                  {currentRegion !== "all" ? ` ${currentRegion} India` : " India"} for the year {currentYear}. It shows
                  that {data[0].value}% of people are healthy, {data[1].value}% have been cured from illnesses, and{" "}
                  {data[2].value}% have unfortunately passed away due to health issues.
                </p>
              </motion.div>

              {/* Suggestion */}
              <motion.div
                variants={itemVariants}
                className="bg-white rounded-xl p-5 shadow-lg border border-gray-100 hover:shadow-xl transition-shadow duration-300"
                whileHover={{ scale: 1.02 }}
              >
                <h2 className="text-xl font-bold text-gray-800 border-b-2 border-indigo-100 pb-2 mb-4">SUGGESTIONS</h2>
                <p className="text-gray-600 leading-relaxed">
                  From the looks of things, we should focus on improving healthcare access in
                  {currentRegion !== "all" ? ` ${currentRegion} India` : " rural areas"}
                  to further increase the cure rate and reduce mortality.
                  {data[2].value > 1.5
                    ? " Urgent intervention is needed to address the higher death rate in this region."
                    : " The current strategies are working well, but continued investment is needed to maintain progress."}
                </p>
              </motion.div>
            </div>
          </div>
        </div>

        <motion.div
          variants={itemVariants}
          className="bg-gray-50 p-4 border-t border-gray-200 text-center text-gray-500 text-sm"
        >
          Data last updated: May {currentYear} | Source: Ministry of Health
        </motion.div>
      </motion.div>
    </div>
  )
}
