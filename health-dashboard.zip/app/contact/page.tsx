"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { useToast } from "@/components/ui/use-toast"
import { Mail, MapPin, Phone } from "lucide-react"

export default function ContactPage() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    subject: "",
    message: "",
  })
  const [isSubmitting, setIsSubmitting] = useState(false)
  const { toast } = useToast()

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    // Simulate API call
    setTimeout(() => {
      setIsSubmitting(false)
      setFormData({
        name: "",
        email: "",
        phone: "",
        subject: "",
        message: "",
      })
      toast({
        title: "Message Sent!",
        description: "We'll get back to you as soon as possible.",
      })
    }, 1500)
  }

  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section className="relative h-[40vh] w-full overflow-hidden bg-black">
        <div className="absolute inset-0 bg-gradient-to-r from-black/80 to-black/40 z-10"></div>
        <div className="absolute inset-0 bg-[url('/images/contact-hero.jpg')] bg-cover bg-center opacity-50"></div>
        <div className="container relative z-20 flex h-full flex-col items-center justify-center text-center">
          <h1 className="font-playfair text-4xl md:text-6xl font-bold text-white mb-4">Contact Us</h1>
          <p className="max-w-2xl text-lg md:text-xl text-gray-200">
            We're here to help with any questions or requests
          </p>
        </div>
      </section>

      {/* Contact Information */}
      <section className="py-20">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
            <div className="flex flex-col items-center text-center p-6 bg-white dark:bg-gray-800 rounded-lg shadow-md">
              <div className="h-16 w-16 rounded-full bg-gold/10 flex items-center justify-center mb-4">
                <Phone className="h-8 w-8 text-gold" />
              </div>
              <h3 className="text-xl font-bold mb-2">Phone</h3>
              <p className="text-gray-600 dark:text-gray-300 mb-4">Call us directly to speak with our team</p>
              <a href="tel:+2348069305651" className="text-gold font-medium hover:underline">
                +234 806 930 5651
              </a>
            </div>
            <div className="flex flex-col items-center text-center p-6 bg-white dark:bg-gray-800 rounded-lg shadow-md">
              <div className="h-16 w-16 rounded-full bg-gold/10 flex items-center justify-center mb-4">
                <Mail className="h-8 w-8 text-gold" />
              </div>
              <h3 className="text-xl font-bold mb-2">Email</h3>
              <p className="text-gray-600 dark:text-gray-300 mb-4">Send us an email and we'll respond promptly</p>
              <a href="mailto:info@royalbreedfashions.com" className="text-gold font-medium hover:underline">
                info@royalbreedfashions.com
              </a>
            </div>
            <div className="flex flex-col items-center text-center p-6 bg-white dark:bg-gray-800 rounded-lg shadow-md">
              <div className="h-16 w-16 rounded-full bg-gold/10 flex items-center justify-center mb-4">
                <MapPin className="h-8 w-8 text-gold" />
              </div>
              <h3 className="text-xl font-bold mb-2">Location</h3>
              <p className="text-gray-600 dark:text-gray-300 mb-4">Visit our showroom in person</p>
              <p className="text-gold font-medium">Lagos, Nigeria</p>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* Contact Form */}
            <div>
              <h2 className="text-3xl font-playfair font-bold mb-6">Send Us a Message</h2>
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label htmlFor="name" className="text-sm font-medium">
                      Full Name
                    </label>
                    <Input id="name" name="name" value={formData.name} onChange={handleChange} required />
                  </div>
                  <div className="space-y-2">
                    <label htmlFor="email" className="text-sm font-medium">
                      Email Address
                    </label>
                    <Input
                      id="email"
                      name="email"
                      type="email"
                      value={formData.email}
                      onChange={handleChange}
                      required
                    />
                  </div>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label htmlFor="phone" className="text-sm font-medium">
                      Phone Number
                    </label>
                    <Input id="phone" name="phone" value={formData.phone} onChange={handleChange} />
                  </div>
                  <div className="space-y-2">
                    <label htmlFor="subject" className="text-sm font-medium">
                      Subject
                    </label>
                    <Input id="subject" name="subject" value={formData.subject} onChange={handleChange} required />
                  </div>
                </div>
                <div className="space-y-2">
                  <label htmlFor="message" className="text-sm font-medium">
                    Message
                  </label>
                  <Textarea
                    id="message"
                    name="message"
                    rows={6}
                    value={formData.message}
                    onChange={handleChange}
                    required
                  />
                </div>
                <Button type="submit" className="w-full bg-gold hover:bg-gold/90 text-black" disabled={isSubmitting}>
                  {isSubmitting ? "Sending..." : "Send Message"}
                </Button>
              </form>
            </div>

            {/* Map or Image */}
            <div className="flex flex-col">
              <h2 className="text-3xl font-playfair font-bold mb-6">Our Location</h2>
              <div className="relative h-[400px] w-full rounded-lg overflow-hidden">
                <iframe
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d253682.45932537!2d3.1191195!3d6.5483!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x103b8b2ae68280c1%3A0xdc9e87a367c3d9cb!2sLagos%2C%20Nigeria!5e0!3m2!1sen!2sus!4v1652345678901!5m2!1sen!2sus"
                  width="100%"
                  height="100%"
                  style={{ border: 0 }}
                  allowFullScreen
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                  className="absolute inset-0"
                ></iframe>
              </div>
              <div className="mt-6">
                <h3 className="text-xl font-bold mb-2">Business Hours</h3>
                <ul className="space-y-2 text-gray-600 dark:text-gray-300">
                  <li className="flex justify-between">
                    <span>Monday - Friday:</span>
                    <span>9:00 AM - 6:00 PM</span>
                  </li>
                  <li className="flex justify-between">
                    <span>Saturday:</span>
                    <span>10:00 AM - 4:00 PM</span>
                  </li>
                  <li className="flex justify-between">
                    <span>Sunday:</span>
                    <span>Closed</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Payment Information */}
      <section className="py-16 bg-gray-50 dark:bg-gray-900">
        <div className="container">
          <h2 className="text-3xl font-playfair font-bold text-center mb-12">Payment Information</h2>
          <div className="max-w-3xl mx-auto bg-white dark:bg-gray-800 rounded-lg shadow-md p-8">
            <p className="text-gray-600 dark:text-gray-300 mb-6">
              For payments and deposits, please use the following account details:
            </p>
            <div className="space-y-4">
              <div className="p-4 border rounded-md">
                <h3 className="font-bold mb-2">Opay</h3>
                <p className="text-gray-600 dark:text-gray-300">Account Name: Prosper Somtochukwu Emeaso</p>
                <p className="text-gray-600 dark:text-gray-300">Account Number: 08069305651</p>
              </div>
              <div className="p-4 border rounded-md">
                <h3 className="font-bold mb-2">Bank Transfer</h3>
                <p className="text-gray-600 dark:text-gray-300">Please contact us for bank transfer details.</p>
              </div>
              <div className="p-4 border rounded-md">
                <h3 className="font-bold mb-2">International Payments</h3>
                <p className="text-gray-600 dark:text-gray-300">We accept PayPal and international bank transfers.</p>
              </div>
            </div>
            <p className="mt-6 text-sm text-gray-500 dark:text-gray-400">
              For any payment-related inquiries, please contact us directly at +2348069305651.
            </p>
          </div>
        </div>
      </section>
    </div>
  )
}
