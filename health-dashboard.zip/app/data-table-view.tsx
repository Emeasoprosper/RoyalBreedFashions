"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { ArrowUpDown, Search } from "lucide-react"

type DataItem = {
  id: string
  region: string
  year: string
  population: number
  cured: number
  death: number
}

const generateData = (): DataItem[] => {
  const regions = ["All Regions", "North India", "South India", "East India", "West India", "Central India"]
  const years = ["2023", "2024", "2025"]

  const data: DataItem[] = []

  regions.forEach((region) => {
    years.forEach((year) => {
      // Generate somewhat realistic data
      const basePopulation = region === "All Regions" ? 90 : 85 + Math.random() * 10
      const baseCured = region === "All Regions" ? 8 : 7 + Math.random() * 5
      const baseDeath = region === "All Regions" ? 2 : 1 + Math.random() * 3

      // Adjust for year (improvement over time)
      const yearFactor = year === "2023" ? 0 : year === "2024" ? 0.5 : 1

      const population = basePopulation + yearFactor
      const cured = baseCured + yearFactor * 0.2
      const death = Math.max(0.5, baseDeath - yearFactor * 0.5)

      data.push({
        id: `${region}-${year}`,
        region,
        year,
        population: Number.parseFloat(population.toFixed(1)),
        cured: Number.parseFloat(cured.toFixed(1)),
        death: Number.parseFloat(death.toFixed(1)),
      })
    })
  })

  return data
}

export default function DataTableView() {
  const [data] = useState<DataItem[]>(generateData())
  const [searchTerm, setSearchTerm] = useState("")
  const [sortConfig, setSortConfig] = useState<{ key: keyof DataItem; direction: "asc" | "desc" } | null>(null)

  const handleSort = (key: keyof DataItem) => {
    let direction: "asc" | "desc" = "asc"

    if (sortConfig && sortConfig.key === key && sortConfig.direction === "asc") {
      direction = "desc"
    }

    setSortConfig({ key, direction })
  }

  const filteredData = data.filter(
    (item) => item.region.toLowerCase().includes(searchTerm.toLowerCase()) || item.year.includes(searchTerm),
  )

  const sortedData = [...filteredData].sort((a, b) => {
    if (!sortConfig) return 0

    const { key, direction } = sortConfig

    if (a[key] < b[key]) {
      return direction === "asc" ? -1 : 1
    }
    if (a[key] > b[key]) {
      return direction === "asc" ? 1 : -1
    }
    return 0
  })

  return (
    <motion.div
      className="p-6 bg-[#ebfefe] rounded-lg shadow-lg"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold">Population Data Table</h2>
        <div className="relative w-64">
          <Search className="absolute left-2 top-2.5 h-4 w-4 text-gray-500" />
          <Input
            placeholder="Search by region or year..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-8"
          />
        </div>
      </div>

      <div className="rounded-md border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="w-[200px]">
                <Button variant="ghost" onClick={() => handleSort("region")} className="flex items-center gap-1">
                  Region <ArrowUpDown className="h-4 w-4" />
                </Button>
              </TableHead>
              <TableHead>
                <Button variant="ghost" onClick={() => handleSort("year")} className="flex items-center gap-1">
                  Year <ArrowUpDown className="h-4 w-4" />
                </Button>
              </TableHead>
              <TableHead className="text-right">
                <Button variant="ghost" onClick={() => handleSort("population")} className="flex items-center gap-1">
                  Population % <ArrowUpDown className="h-4 w-4" />
                </Button>
              </TableHead>
              <TableHead className="text-right">
                <Button variant="ghost" onClick={() => handleSort("cured")} className="flex items-center gap-1">
                  Cured % <ArrowUpDown className="h-4 w-4" />
                </Button>
              </TableHead>
              <TableHead className="text-right">
                <Button variant="ghost" onClick={() => handleSort("death")} className="flex items-center gap-1">
                  Death % <ArrowUpDown className="h-4 w-4" />
                </Button>
              </TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {sortedData.map((item) => (
              <TableRow key={item.id}>
                <TableCell className="font-medium">{item.region}</TableCell>
                <TableCell>{item.year}</TableCell>
                <TableCell className="text-right">{item.population}%</TableCell>
                <TableCell className="text-right">{item.cured}%</TableCell>
                <TableCell className="text-right">{item.death}%</TableCell>
              </TableRow>
            ))}
            {sortedData.length === 0 && (
              <TableRow>
                <TableCell colSpan={5} className="text-center py-4">
                  No results found
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>
    </motion.div>
  )
}
