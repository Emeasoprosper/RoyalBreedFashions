"use client"

import { useState, useEffect } from "react"
import { PieChart, Pie, Cell, ResponsiveContainer, Sector } from "recharts"
import { motion } from "framer-motion"

export default function SimplifiedLayout() {
  const [activeIndex, setActiveIndex] = useState<number | null>(null)
  const [isLoaded, setIsLoaded] = useState(false)

  useEffect(() => {
    setIsLoaded(true)
  }, [])

  const data = [
    { name: "Population", value: 90.3, color: "gray" },
    { name: "Cured", value: 8.0, color: "green" },
    { name: "Death", value: 1.7, color: "red" },
  ]

  const renderActiveShape = (props: any) => {
    const { cx, cy, innerRadius, outerRadius, startAngle, endAngle, fill, payload, percent, value } = props

    return (
      <g>
        <Sector
          cx={cx}
          cy={cy}
          innerRadius={innerRadius}
          outerRadius={outerRadius + 10}
          startAngle={startAngle}
          endAngle={endAngle}
          fill={fill}
        />
        <text x={cx} y={cy} dy={-20} textAnchor="middle" fill="#333" fontSize={16} fontWeight="bold">
          {payload.name}
        </text>
        <text x={cx} y={cy} textAnchor="middle" fill="#333" fontSize={20} fontWeight="bold">
          {`${value}%`}
        </text>
      </g>
    )
  }

  const onPieEnter = (_: any, index: number) => {
    setActiveIndex(index)
  }

  const onPieLeave = () => {
    setActiveIndex(null)
  }

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
      },
    },
  }

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        duration: 0.5,
      },
    },
  }

  return (
    <div className="min-h-screen bg-[#f5f5f5] p-6">
      <motion.div
        initial="hidden"
        animate={isLoaded ? "visible" : "hidden"}
        variants={containerVariants}
        className="container mx-auto"
      >
        {/* This is the key part - using CSS Grid with equal height columns */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5 auto-rows-fr">
          {/* Left side - Chart */}
          <motion.div variants={itemVariants} className="h-full">
            <div className="bg-[#ebfefe] p-6 rounded-lg shadow-lg h-full flex flex-col">
              <h1 className="text-2xl font-bold mb-4">Population Distribution</h1>
              <p className="mb-4">
                This pie chart shows the distribution of the total population into cured, death, and others.
              </p>
              <div className="flex-grow flex items-center justify-center">
                <div className="h-[300px] w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        activeIndex={activeIndex !== null ? activeIndex : undefined}
                        activeShape={renderActiveShape}
                        data={data}
                        cx="50%"
                        cy="50%"
                        innerRadius={70}
                        outerRadius={110}
                        dataKey="value"
                        onMouseEnter={onPieEnter}
                        onMouseLeave={onPieLeave}
                      >
                        {data.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} stroke="#fff" strokeWidth={2} />
                        ))}
                      </Pie>
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </div>
            </div>
          </motion.div>

          {/* Right side - Legend, Summary, Suggestions */}
          <motion.div variants={itemVariants} className="h-full">
            <div className="h-full grid grid-rows-3 gap-5">
              {/* Legend */}
              <motion.div
                className="bg-[#ebfefe] p-6 rounded-lg shadow-lg"
                whileHover={{ boxShadow: "0 10px 25px rgba(0, 0, 0, 0.1)" }}
                transition={{ duration: 0.3 }}
              >
                <h1 className="text-2xl font-bold mb-4">LEGENDS</h1>
                <div className="space-y-2">
                  <motion.div className="flex items-center gap-3" whileHover={{ x: 5 }} transition={{ duration: 0.2 }}>
                    <div className="w-[30px] h-[30px] bg-gray rounded-md"></div>
                    <p className="m-0">Population percentage</p>
                  </motion.div>

                  <motion.div className="flex items-center gap-3" whileHover={{ x: 5 }} transition={{ duration: 0.2 }}>
                    <div className="w-[30px] h-[30px] bg-green rounded-md"></div>
                    <p className="m-0">Cured percentage</p>
                  </motion.div>

                  <motion.div className="flex items-center gap-3" whileHover={{ x: 5 }} transition={{ duration: 0.2 }}>
                    <div className="w-[30px] h-[30px] bg-red rounded-md"></div>
                    <p className="m-0">Death percentage</p>
                  </motion.div>
                </div>
              </motion.div>

              {/* Summary */}
              <motion.div
                className="bg-[#ebfefe] p-6 rounded-lg shadow-lg"
                whileHover={{ boxShadow: "0 10px 25px rgba(0, 0, 0, 0.1)" }}
                transition={{ duration: 0.3 }}
              >
                <h1 className="text-2xl font-bold mb-4">SUMMARY</h1>
                <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.5, duration: 0.5 }}>
                  This chart displays the health statistics for India. The data shows that 90.3% of the population is
                  healthy, 8.0% have been cured from illnesses, and 1.7% have unfortunately passed away.
                </motion.p>
              </motion.div>

              {/* Suggestions */}
              <motion.div
                className="bg-[#ebfefe] p-6 rounded-lg shadow-lg"
                whileHover={{ boxShadow: "0 10px 25px rgba(0, 0, 0, 0.1)" }}
                transition={{ duration: 0.3 }}
              >
                <h1 className="text-2xl font-bold mb-4">SUGGESTIONS</h1>
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.9, duration: 0.5 }}
                >
                  <p>Based on the current data, we recommend:</p>
                  <ul className="list-disc pl-5 mt-2">
                    <motion.li
                      initial={{ x: -20, opacity: 0 }}
                      animate={{ x: 0, opacity: 1 }}
                      transition={{ delay: 1.0, duration: 0.3 }}
                    >
                      Maintain current healthcare initiatives that have successfully kept mortality rates low
                    </motion.li>
                  </ul>
                </motion.div>
              </motion.div>
            </div>
          </motion.div>
        </div>

        <motion.div variants={itemVariants} className="mt-6 text-center text-gray-500 text-sm">
          Data last updated: May 2025 | Source: Ministry of Health
        </motion.div>
      </motion.div>
    </div>
  )
}
