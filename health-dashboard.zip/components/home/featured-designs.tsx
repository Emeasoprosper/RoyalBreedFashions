"use client"

import { useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ArrowRight } from "lucide-react"

// Sample data - in a real app, this would come from your database
const designs = {
  suits: [
    {
      id: "suit-1",
      name: "Classic Black Tuxedo",
      image: "/placeholder.svg?height=400&width=300",
      price: "₦75,000",
    },
    {
      id: "suit-2",
      name: "Navy Blue Three-Piece",
      image: "/placeholder.svg?height=400&width=300",
      price: "₦65,000",
    },
    {
      id: "suit-3",
      name: "Gray Pinstripe Suit",
      image: "/placeholder.svg?height=400&width=300",
      price: "₦60,000",
    },
    {
      id: "suit-4",
      name: "Burgundy Wedding Suit",
      image: "/placeholder.svg?height=400&width=300",
      price: "₦80,000",
    },
  ],
  shirts: [
    {
      id: "shirt-1",
      name: "White Dress Shirt",
      image: "/placeholder.svg?height=400&width=300",
      price: "₦15,000",
    },
    {
      id: "shirt-2",
      name: "Light Blue Oxford",
      image: "/placeholder.svg?height=400&width=300",
      price: "₦18,000",
    },
    {
      id: "shirt-3",
      name: "Striped Business Shirt",
      image: "/placeholder.svg?height=400&width=300",
      price: "₦20,000",
    },
    {
      id: "shirt-4",
      name: "Black Formal Shirt",
      image: "/placeholder.svg?height=400&width=300",
      price: "₦17,000",
    },
  ],
  traditional: [
    {
      id: "trad-1",
      name: "Embroidered Agbada",
      image: "/placeholder.svg?height=400&width=300",
      price: "₦45,000",
    },
    {
      id: "trad-2",
      name: "Senator Style",
      image: "/placeholder.svg?height=400&width=300",
      price: "₦35,000",
    },
    {
      id: "trad-3",
      name: "Luxury Kaftan",
      image: "/placeholder.svg?height=400&width=300",
      price: "₦40,000",
    },
    {
      id: "trad-4",
      name: "Wedding Agbada Set",
      image: "/placeholder.svg?height=400&width=300",
      price: "₦65,000",
    },
  ],
}

export default function FeaturedDesigns() {
  const [activeTab, setActiveTab] = useState("suits")

  return (
    <section className="py-20">
      <div className="container">
        <div className="flex flex-col md:flex-row justify-between items-center mb-12">
          <div>
            <h2 className="text-3xl md:text-4xl font-playfair font-bold mb-4">Featured Designs</h2>
            <p className="text-gray-600 dark:text-gray-300 max-w-2xl">
              Explore our collection of premium men's fashion designs, crafted with attention to detail and the finest
              materials.
            </p>
          </div>
          <Button asChild variant="outline" className="mt-4 md:mt-0 border-gold text-gold hover:bg-gold/10">
            <Link href="/designs">
              View All Designs <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
          </Button>
        </div>

        <Tabs defaultValue="suits" value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-3 mb-8">
            <TabsTrigger value="suits">Suits</TabsTrigger>
            <TabsTrigger value="shirts">Shirts</TabsTrigger>
            <TabsTrigger value="traditional">Traditional</TabsTrigger>
          </TabsList>

          {Object.entries(designs).map(([category, items]) => (
            <TabsContent key={category} value={category} className="mt-0">
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                {items.map((design) => (
                  <Card key={design.id} className="overflow-hidden group">
                    <div className="relative h-80 overflow-hidden">
                      <Image
                        src={design.image || "/placeholder.svg"}
                        alt={design.name}
                        fill
                        className="object-cover transition-transform duration-300 group-hover:scale-105"
                      />
                      <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                        <Button asChild className="bg-gold hover:bg-gold/90 text-black">
                          <Link href={`/designs/${design.id}`}>View Details</Link>
                        </Button>
                      </div>
                    </div>
                    <CardContent className="p-4">
                      <h3 className="font-bold text-lg mb-1">{design.name}</h3>
                      <p className="text-gold font-medium">{design.price}</p>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>
          ))}
        </Tabs>
      </div>
    </section>
  )
}
