"use client"

import { useState, useEffect } from "react"
import Image from "next/image"
import { Card, CardContent } from "@/components/ui/card"
import { ChevronLeft, ChevronRight, Star } from "lucide-react"
import { Button } from "@/components/ui/button"

// Sample testimonials - in a real app, this would come from your database
const testimonials = [
  {
    id: 1,
    name: "John Doe",
    role: "Business Executive",
    image: "/placeholder.svg?height=100&width=100",
    quote:
      "Royal Breed Fashions has completely transformed my wardrobe. The attention to detail and quality of craftsmanship is unmatched. I've never received so many compliments on my suits before!",
    rating: 5,
  },
  {
    id: 2,
    name: "Michael Johnson",
    role: "Wedding Client",
    image: "/placeholder.svg?height=100&width=100",
    quote:
      "I ordered a custom suit for my wedding day and couldn't be happier with the result. The team at Royal Breed Fashions made sure everything was perfect, from the measurements to the fabric selection.",
    rating: 5,
  },
  {
    id: 3,
    name: "David Williams",
    role: "Corporate Professional",
    image: "/placeholder.svg?height=100&width=100",
    quote:
      "The quality and fit of my Royal Breed suit is exceptional. Their customer service is top-notch, and they really take the time to understand what you're looking for.",
    rating: 4,
  },
  {
    id: 4,
    name: "Robert Brown",
    role: "Repeat Customer",
    image: "/placeholder.svg?height=100&width=100",
    quote:
      "I've been a customer for over 3 years now, and Royal Breed Fashions never disappoints. Their traditional designs are both authentic and modern at the same time.",
    rating: 5,
  },
]

export default function TestimonialSlider() {
  const [currentIndex, setCurrentIndex] = useState(0)
  const [autoplay, setAutoplay] = useState(true)

  const nextTestimonial = () => {
    setCurrentIndex((prevIndex) => (prevIndex + 1) % testimonials.length)
  }

  const prevTestimonial = () => {
    setCurrentIndex((prevIndex) => (prevIndex - 1 + testimonials.length) % testimonials.length)
  }

  useEffect(() => {
    if (!autoplay) return

    const interval = setInterval(() => {
      nextTestimonial()
    }, 5000)

    return () => clearInterval(interval)
  }, [autoplay, currentIndex])

  return (
    <section className="py-20 bg-white dark:bg-gray-800">
      <div className="container">
        <h2 className="text-3xl md:text-4xl font-playfair font-bold text-center mb-16">What Our Clients Say</h2>

        <div className="relative max-w-4xl mx-auto">
          <div className="overflow-hidden">
            <div
              className="flex transition-transform duration-500 ease-in-out"
              style={{ transform: `translateX(-${currentIndex * 100}%)` }}
            >
              {testimonials.map((testimonial) => (
                <div key={testimonial.id} className="w-full flex-shrink-0 px-4">
                  <Card className="border-none shadow-lg">
                    <CardContent className="p-8 text-center">
                      <div className="flex justify-center mb-6">
                        <div className="relative h-20 w-20 rounded-full overflow-hidden border-4 border-gold">
                          <Image
                            src={testimonial.image || "/placeholder.svg"}
                            alt={testimonial.name}
                            fill
                            className="object-cover"
                          />
                        </div>
                      </div>
                      <div className="flex justify-center mb-4">
                        {[...Array(5)].map((_, i) => (
                          <Star
                            key={i}
                            className={`h-5 w-5 ${i < testimonial.rating ? "text-gold fill-gold" : "text-gray-300"}`}
                          />
                        ))}
                      </div>
                      <p className="text-lg italic mb-6">"{testimonial.quote}"</p>
                      <h3 className="font-bold text-xl">{testimonial.name}</h3>
                      <p className="text-gray-500 dark:text-gray-400">{testimonial.role}</p>
                    </CardContent>
                  </Card>
                </div>
              ))}
            </div>
          </div>

          <Button
            variant="outline"
            size="icon"
            className="absolute left-0 top-1/2 -translate-y-1/2 -translate-x-4 md:-translate-x-12 border-gold text-gold hover:bg-gold/10 z-10"
            onClick={prevTestimonial}
            onMouseEnter={() => setAutoplay(false)}
            onMouseLeave={() => setAutoplay(true)}
          >
            <ChevronLeft className="h-6 w-6" />
          </Button>

          <Button
            variant="outline"
            size="icon"
            className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-4 md:translate-x-12 border-gold text-gold hover:bg-gold/10 z-10"
            onClick={nextTestimonial}
            onMouseEnter={() => setAutoplay(false)}
            onMouseLeave={() => setAutoplay(true)}
          >
            <ChevronRight className="h-6 w-6" />
          </Button>

          <div className="flex justify-center mt-8 gap-2">
            {testimonials.map((_, index) => (
              <button
                key={index}
                className={`h-2 w-2 rounded-full transition-all ${
                  currentIndex === index ? "w-6 bg-gold" : "bg-gray-300 dark:bg-gray-600"
                }`}
                onClick={() => setCurrentIndex(index)}
                onMouseEnter={() => setAutoplay(false)}
                onMouseLeave={() => setAutoplay(true)}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
