"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { motion } from "framer-motion"

export function Filters({ onFilterChange }: { onFilterChange: (region: string, year: string) => void }) {
  const [region, setRegion] = useState("all")
  const [year, setYear] = useState("2025")

  const handleRegionChange = (value: string) => {
    setRegion(value)
    onFilterChange(value, year)
  }

  const handleYearChange = (value: string) => {
    setYear(value)
    onFilterChange(region, value)
  }

  return (
    <motion.div
      className="flex flex-wrap gap-4 mb-6"
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.2 }}
    >
      <div className="flex flex-col gap-1">
        <label className="text-sm font-medium text-gray-700">Region</label>
        <Select value={region} onValueChange={handleRegionChange}>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="Select region" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Regions</SelectItem>
            <SelectItem value="north">North India</SelectItem>
            <SelectItem value="south">South India</SelectItem>
            <SelectItem value="east">East India</SelectItem>
            <SelectItem value="west">West India</SelectItem>
            <SelectItem value="central">Central India</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="flex flex-col gap-1">
        <label className="text-sm font-medium text-gray-700">Year</label>
        <Select value={year} onValueChange={handleYearChange}>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="Select year" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="2023">2023</SelectItem>
            <SelectItem value="2024">2024</SelectItem>
            <SelectItem value="2025">2025</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="flex items-end">
        <Button
          variant="outline"
          onClick={() => {
            setRegion("all")
            setYear("2025")
            onFilterChange("all", "2025")
          }}
          className="h-10"
        >
          Reset Filters
        </Button>
      </div>
    </motion.div>
  )
}
