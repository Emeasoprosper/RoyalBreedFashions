"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Download, FileDown, FileSpreadsheet } from "lucide-react"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { motion } from "framer-motion"

export function DownloadOptions({ data }: { data: any[] }) {
  const [isDownloading, setIsDownloading] = useState(false)

  const downloadAsCSV = () => {
    setIsDownloading(true)

    try {
      // Create CSV content
      const headers = ["Category", "Percentage"]
      const csvContent = [headers.join(","), ...data.map((item) => `${item.name},${item.value}`)].join("\n")

      // Create download link
      const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" })
      const url = URL.createObjectURL(blob)
      const link = document.createElement("a")
      link.setAttribute("href", url)
      link.setAttribute("download", "population_distribution.csv")
      document.body.appendChild(link)
      link.click()
      document.body.removeChild(link)
    } catch (error) {
      console.error("Error downloading CSV:", error)
    } finally {
      setIsDownloading(false)
    }
  }

  const downloadAsImage = () => {
    setIsDownloading(true)

    try {
      // Find the chart container
      const chartContainer = document.querySelector(".recharts-wrapper")
      if (!chartContainer) {
        console.error("Chart container not found")
        return
      }

      // Use html2canvas to capture the chart (this is a simplified example)
      // In a real implementation, you would use a library like html2canvas
      alert("In a real implementation, this would download the chart as an image")
    } catch (error) {
      console.error("Error downloading image:", error)
    } finally {
      setIsDownloading(false)
    }
  }

  return (
    <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.3 }}>
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="outline" className="gap-2">
            <Download className="h-4 w-4" />
            Download
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent>
          <DropdownMenuItem onClick={downloadAsCSV} disabled={isDownloading}>
            <FileSpreadsheet className="mr-2 h-4 w-4" />
            Download as CSV
          </DropdownMenuItem>
          <DropdownMenuItem onClick={downloadAsImage} disabled={isDownloading}>
            <FileDown className="mr-2 h-4 w-4" />
            Download as Image
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
    </motion.div>
  )
}
