"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Send } from "lucide-react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

type Message = {
  id: string
  content: string
  sender: "user" | "bot"
  timestamp: Date
}

// Sample responses - in a real app, this would be connected to an AI service
const sampleResponses = [
  "Welcome to Royal Breed Fassions! How can I assist you today?",
  "Our custom suits start at ₦60,000, depending on the fabric and design complexity.",
  "Yes, we offer international shipping. Delivery times vary by location.",
  "We typically require 2-3 weeks for custom tailoring, depending on our current workload.",
  "You can submit your measurements through your account dashboard after registering.",
  "We accept payments via PayPal, Opay, Palmpay, and bank transfers.",
  "Yes, we offer alterations if your garment doesn't fit perfectly.",
  "Our fabrics are sourced from premium mills in Italy, England, and Turkey.",
  "You can book a consultation through the contact page or by calling +2348069305651.",
]

export default function ChatbotInterface() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "1",
      content: "Hello! I'm your Royal Breed Fassions assistant. How can I help you today?",
      sender: "bot",
      timestamp: new Date(),
    },
  ])
  const [input, setInput] = useState("")
  const [isTyping, setIsTyping] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault()

    if (!input.trim()) return

    // Add user message
    const userMessage: Message = {
      id: Date.now().toString(),
      content: input,
      sender: "user",
      timestamp: new Date(),
    }

    setMessages((prev) => [...prev, userMessage])
    setInput("")
    setIsTyping(true)

    // Simulate bot response
    setTimeout(() => {
      const randomResponse = sampleResponses[Math.floor(Math.random() * sampleResponses.length)]

      const botMessage: Message = {
        id: (Date.now() + 1).toString(),
        content: randomResponse,
        sender: "bot",
        timestamp: new Date(),
      }

      setMessages((prev) => [...prev, botMessage])
      setIsTyping(false)
    }, 1500)
  }

  return (
    <div className="flex flex-col h-[500px]">
      <div className="flex-1 overflow-y-auto p-4">
        {messages.map((message) => (
          <div key={message.id} className={`flex ${message.sender === "user" ? "justify-end" : "justify-start"} mb-4`}>
            {message.sender === "bot" && (
              <Avatar className="h-8 w-8 mr-2">
                <AvatarImage
                  src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Copy%20of%20ROYALBREED.jpg-7YL9WfU5iw7CtZzGQyQ0vuhXLxzcKh.jpeg"
                  alt="Royal Breed"
                  className="object-cover"
                />
                <AvatarFallback>RB</AvatarFallback>
              </Avatar>
            )}
            <div
              className={`max-w-[80%] rounded-lg px-4 py-2 ${
                message.sender === "user" ? "bg-gold text-black" : "bg-gray-100 dark:bg-gray-800"
              }`}
            >
              <p>{message.content}</p>
              <p className="text-xs opacity-70 mt-1">
                {message.timestamp.toLocaleTimeString([], {
                  hour: "2-digit",
                  minute: "2-digit",
                })}
              </p>
            </div>
          </div>
        ))}

        {isTyping && (
          <div className="flex justify-start mb-4">
            <Avatar className="h-8 w-8 mr-2">
              <AvatarImage
                src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Copy%20of%20ROYALBREED.jpg-7YL9WfU5iw7CtZzGQyQ0vuhXLxzcKh.jpeg"
                alt="Royal Breed"
              />
              <AvatarFallback>RB</AvatarFallback>
            </Avatar>
            <div className="bg-gray-100 dark:bg-gray-800 rounded-lg px-4 py-2">
              <div className="flex space-x-1">
                <div
                  className="h-2 w-2 rounded-full bg-gray-400 animate-bounce"
                  style={{ animationDelay: "0ms" }}
                ></div>
                <div
                  className="h-2 w-2 rounded-full bg-gray-400 animate-bounce"
                  style={{ animationDelay: "150ms" }}
                ></div>
                <div
                  className="h-2 w-2 rounded-full bg-gray-400 animate-bounce"
                  style={{ animationDelay: "300ms" }}
                ></div>
              </div>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      <form onSubmit={handleSend} className="border-t p-4 flex gap-2">
        <Input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Type your message..."
          className="flex-1"
        />
        <Button type="submit" size="icon" className="bg-gold hover:bg-gold/90 text-black">
          <Send className="h-4 w-4" />
        </Button>
      </form>
    </div>
  )
}
